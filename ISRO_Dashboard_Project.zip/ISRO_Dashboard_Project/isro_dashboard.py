import pandas as pd
import streamlit as st
import plotly.express as px

# File path for the dataset
FILE_PATH = "data/ISRO mission launches.csv"

# Load the dataset
def load_data(file_path):
    data = pd.read_csv(file_path, encoding='ISO-8859-1')
    # Standardize column names
    data.columns = [col.strip().replace(" ", "_") for col in data.columns]
    return data

# Clean the dataset
def clean_data(data):
    data['Launch_Date'] = pd.to_datetime(data['Launch_Date'], errors='coerce')
    data['Year'] = data['Launch_Date'].dt.year
    data['Orbit_Type'] = data['Orbit_Type'].fillna('Unknown')
    data['Application'] = data['Application'].fillna('Unknown')
    return data

# Visualization: Launches by Year
def plot_launches_by_year(data):
    year_counts = data.groupby('Year').size().reset_index(name='Count')
    fig = px.bar(year_counts, x='Year', y='Count', title='ISRO Launches by Year', labels={'Count': 'Number of Launches'})
    return fig

# Visualization: Launches by Application
def plot_launches_by_application(data):
    app_counts = data['Application'].value_counts().reset_index()
    app_counts.columns = ['Application', 'Count']
    fig = px.pie(app_counts, values='Count', names='Application', title='Launches by Application')
    return fig

# Visualization: Launches by Orbit Type
def plot_launches_by_orbit(data):
    orbit_counts = data['Orbit_Type'].value_counts().reset_index()
    orbit_counts.columns = ['Orbit_Type', 'Count']
    fig = px.bar(orbit_counts, x='Orbit_Type', y='Count', title='Launches by Orbit Type', labels={'Count': 'Number of Launches'})
    return fig

# Streamlit Dashboard
def main():
    st.title("ISRO Mission Launch Dashboard")
    st.sidebar.title("Dashboard Controls")

    # Load and clean data
    data = load_data(FILE_PATH)
    data = clean_data(data)

    # Show dataset
    if st.sidebar.checkbox("Show Raw Data"):
        st.subheader("Raw Data")
        st.write(data)

    # Launches by Year
    st.subheader("Launches by Year")
    st.plotly_chart(plot_launches_by_year(data))

    # Launches by Application
    st.subheader("Launches by Application")
    st.plotly_chart(plot_launches_by_application(data))

    # Launches by Orbit Type
    st.subheader("Launches by Orbit Type")
    st.plotly_chart(plot_launches_by_orbit(data))

if __name__ == "__main__":
    main()
